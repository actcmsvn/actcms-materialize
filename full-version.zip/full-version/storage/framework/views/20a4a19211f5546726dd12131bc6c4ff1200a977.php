<div style="bottom: 50px; right: 19px;" class="fixed-action-btn direction-top"><a
        class="btn-floating btn-large gradient-45deg-light-blue-cyan gradient-shadow"><i
            class="material-icons">add</i></a>
    <ul>
        <li><a href="<?php echo e(asset('css-helpers')); ?>" class="btn-floating blue"><i class="material-icons">help_outline</i></a>
        </li>
        <li><a href="<?php echo e(asset('cards-extended')); ?>" class="btn-floating green"><i class="material-icons">widgets</i></a>
        </li>
        <li><a href="<?php echo e(asset('app-calendar')); ?>" class="btn-floating amber"><i class="material-icons">today</i></a></li>
        <li><a href="<?php echo e(asset('app-email')); ?>" class="btn-floating red"><i class="material-icons">mail_outline</i></a>
        </li>
    </ul>
</div><?php /**PATH /var/www/html/materialize-admin/materialize-html-laravel-template/resources/views/pages/sidebar/fab-menu.blade.php ENDPATH**/ ?>